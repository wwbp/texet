# AWS Staging Infra Setup (one-time manual)

This is a short, one-time staging infra setup guide for AWS. It is manual on purpose and meant
to happen before CI/CD (for example, GitHub Actions) is in place. You can use either:

- AWS Console (web UI)
- AWS CLI + EB CLI (local commands)

## What you will create

- An Elastic Beanstalk (EB) environment running the API (Docker).
- An RDS PostgreSQL database (private).
- Security rules so EB can reach RDS.
- Environment variables set on EB (secrets live there for now).

## Before you start

Decide these once:

- AWS region
- EB application name and environment name
- RDS instance identifier, database name, master username/password
- VPC and subnets (use an existing VPC if you have one; otherwise create a simple VPC)

You need:

- AWS account with permissions to create EB, RDS, VPC, and security groups
- This repo ready to build the Docker image

## Required environment values

Set these on the EB environment:

- `DATABASE_URL` (database connection string)
- `OPENAI_API_KEY`
- `OPENAI_MODEL`
- `SMS_OUTBOUND_URL`

Optional:

- `SMS_TIMEOUT_SECONDS`
- `ADMIN_USERNAME`, `ADMIN_PASSWORD`, `ADMIN_SECRET_KEY`
- `ADMIN_SESSION_TTL_SECONDS`

Example `DATABASE_URL`:
`postgresql+asyncpg://texet_user:<password>@<rds-endpoint>:5432/texet`

If RDS requires SSL/TLS, append `?sslmode=require`.

## Step-by-step (AWS Console)

1) Create or choose a VPC  
   - Use a VPC with **public subnets** for the EB load balancer and **private subnets** for EB instances + RDS.
   - If you do not have one, use the VPC wizard and create a simple VPC with public + private subnets.

2) Create the RDS database  
   - Engine: PostgreSQL  
   - Public access: **No**  
   - Subnets: private subnets  
   - Security group: allow inbound `5432` from the EB instance security group

3) Create the EB application and environment  
   - Platform: **Docker (single container, load balanced)**  
   - Instance type: small (staging)  
   - VPC: ALB in public subnets, instances in private subnets  
   - Environment variables: set the required values above  
   - Health check path: `/health`

4) Deploy the app  
   - Upload a source bundle (zip) or use the EB console deploy flow.

5) Run migrations  
   - SSH to the EB instance and run:
     - `sudo docker exec <container_id> alembic upgrade head`

6) Create an API key  
   - `sudo docker exec <container_id> uv run python -m app.auth.cli`

7) Verify  
   - `https://<eb-url>/health`  
   - `https://<eb-url>/db/health`

## Step-by-step (AWS CLI + EB CLI)

1) Configure AWS locally:

```bash
aws configure
```

2) Create VPC + subnets (skip if you already have them)

Set a few shell vars once:

```bash
export AWS_REGION=us-east-1
export VPC_NAME=texet-staging
export VPC_CIDR=10.50.0.0/16
```

Create the VPC:

```bash
VPC_ID=$(aws ec2 create-vpc --cidr-block "$VPC_CIDR" --tag-specifications "ResourceType=vpc,Tags=[{Key=Name,Value=$VPC_NAME}]" --region "$AWS_REGION" --query "Vpc.VpcId" --output text)
aws ec2 modify-vpc-attribute --vpc-id "$VPC_ID" --enable-dns-support "{\"Value\":true}" --region "$AWS_REGION"
aws ec2 modify-vpc-attribute --vpc-id "$VPC_ID" --enable-dns-hostnames "{\"Value\":true}" --region "$AWS_REGION"
```

Create public subnets (for ALB):

```bash
PUB_A=$(aws ec2 create-subnet --vpc-id "$VPC_ID" --availability-zone "${AWS_REGION}a" --cidr-block 10.50.0.0/24 --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value=$VPC_NAME-public-a}]" --region "$AWS_REGION" --query "Subnet.SubnetId" --output text)
PUB_B=$(aws ec2 create-subnet --vpc-id "$VPC_ID" --availability-zone "${AWS_REGION}b" --cidr-block 10.50.1.0/24 --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value=$VPC_NAME-public-b}]" --region "$AWS_REGION" --query "Subnet.SubnetId" --output text)
aws ec2 modify-subnet-attribute --subnet-id "$PUB_A" --map-public-ip-on-launch --region "$AWS_REGION"
aws ec2 modify-subnet-attribute --subnet-id "$PUB_B" --map-public-ip-on-launch --region "$AWS_REGION"
```

Create private subnets (for EB instances + RDS):

```bash
PRIV_A=$(aws ec2 create-subnet --vpc-id "$VPC_ID" --availability-zone "${AWS_REGION}a" --cidr-block 10.50.10.0/24 --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value=$VPC_NAME-private-a}]" --region "$AWS_REGION" --query "Subnet.SubnetId" --output text)
PRIV_B=$(aws ec2 create-subnet --vpc-id "$VPC_ID" --availability-zone "${AWS_REGION}b" --cidr-block 10.50.11.0/24 --tag-specifications "ResourceType=subnet,Tags=[{Key=Name,Value=$VPC_NAME-private-b}]" --region "$AWS_REGION" --query "Subnet.SubnetId" --output text)
```

Create internet gateway + public route table:

```bash
IGW_ID=$(aws ec2 create-internet-gateway --tag-specifications "ResourceType=internet-gateway,Tags=[{Key=Name,Value=$VPC_NAME-igw}]" --region "$AWS_REGION" --query "InternetGateway.InternetGatewayId" --output text)
aws ec2 attach-internet-gateway --internet-gateway-id "$IGW_ID" --vpc-id "$VPC_ID" --region "$AWS_REGION"
PUB_RT=$(aws ec2 create-route-table --vpc-id "$VPC_ID" --tag-specifications "ResourceType=route-table,Tags=[{Key=Name,Value=$VPC_NAME-public-rt}]" --region "$AWS_REGION" --query "RouteTable.RouteTableId" --output text)
aws ec2 create-route --route-table-id "$PUB_RT" --destination-cidr-block 0.0.0.0/0 --gateway-id "$IGW_ID" --region "$AWS_REGION"
aws ec2 associate-route-table --route-table-id "$PUB_RT" --subnet-id "$PUB_A" --region "$AWS_REGION"
aws ec2 associate-route-table --route-table-id "$PUB_RT" --subnet-id "$PUB_B" --region "$AWS_REGION"
```

Create NAT gateway + private route table (so private instances can reach the internet):

```bash
EIP_ALLOC=$(aws ec2 allocate-address --domain vpc --region "$AWS_REGION" --query "AllocationId" --output text)
NAT_ID=$(aws ec2 create-nat-gateway --subnet-id "$PUB_A" --allocation-id "$EIP_ALLOC" --region "$AWS_REGION" --query "NatGateway.NatGatewayId" --output text)
PRIV_RT=$(aws ec2 create-route-table --vpc-id "$VPC_ID" --tag-specifications "ResourceType=route-table,Tags=[{Key=Name,Value=$VPC_NAME-private-rt}]" --region "$AWS_REGION" --query "RouteTable.RouteTableId" --output text)
aws ec2 create-route --route-table-id "$PRIV_RT" --destination-cidr-block 0.0.0.0/0 --nat-gateway-id "$NAT_ID" --region "$AWS_REGION"
aws ec2 associate-route-table --route-table-id "$PRIV_RT" --subnet-id "$PRIV_A" --region "$AWS_REGION"
aws ec2 associate-route-table --route-table-id "$PRIV_RT" --subnet-id "$PRIV_B" --region "$AWS_REGION"
```

3) Create security groups (EB and RDS)

```bash
EB_SG=$(aws ec2 create-security-group --group-name "$VPC_NAME-eb-sg" --description "EB instances" --vpc-id "$VPC_ID" --region "$AWS_REGION" --query "GroupId" --output text)
RDS_SG=$(aws ec2 create-security-group --group-name "$VPC_NAME-rds-sg" --description "RDS access from EB" --vpc-id "$VPC_ID" --region "$AWS_REGION" --query "GroupId" --output text)
aws ec2 authorize-security-group-ingress --group-id "$RDS_SG" --protocol tcp --port 5432 --source-group "$EB_SG" --region "$AWS_REGION"
```

4) Create the RDS subnet group + database

```bash
aws rds create-db-subnet-group --db-subnet-group-name "$VPC_NAME-rds-subnets" --db-subnet-group-description "RDS private subnets" --subnet-ids "$PRIV_A" "$PRIV_B" --region "$AWS_REGION"
aws rds create-db-instance \
  --db-instance-identifier texet-staging \
  --engine postgres \
  --engine-version 16.9 \
  --db-instance-class db.t3.small \
  --allocated-storage 20 \
  --storage-type gp3 \
  --master-username <DB_USER> \
  --master-user-password <DB_PASSWORD> \
  --db-name texet \
  --db-subnet-group-name "$VPC_NAME-rds-subnets" \
  --vpc-security-group-ids "$RDS_SG" \
  --no-publicly-accessible \
  --backup-retention-period 7 \
  --region "$AWS_REGION"
```

Wait until the DB is available, then get the endpoint:

```bash
aws rds describe-db-instances --db-instance-identifier texet-staging --region "$AWS_REGION" --query "DBInstances[0].Endpoint.Address" --output text
```

5) Initialize EB and create the environment:

```bash
eb init -p docker <app-name> --region <region>
eb create <env-name> --single --instance_type t3.small
```

If you created a new VPC above, the easiest path is to use the AWS Console to attach the EB
environment to your VPC + public subnets. EB CLI VPC wiring is possible but more advanced;
use the console unless you already have an EB config template.

6) Set environment variables:

```bash
eb setenv DATABASE_URL=... OPENAI_API_KEY=... OPENAI_MODEL=... SMS_OUTBOUND_URL=...
```

7) Deploy:

```bash
eb deploy
```

8) Run migrations + create API key:

```bash
eb ssh
sudo docker ps
sudo docker exec <container_id> alembic upgrade head
sudo docker exec <container_id> uv run python -m app.auth.cli
```

9) Verify:

- `https://<eb-url>/health`
- `https://<eb-url>/db/health`

## Record this once

Keep these values for future reference:

- AWS region
- EB application name and environment name
- EB URL
- RDS instance identifier and endpoint
- `DATABASE_URL`
- Whether admin UI is enabled

## Troubleshooting (short)

- **EB cannot connect to RDS** → check RDS security group inbound rule (allow from EB SG).
- **500 on startup** → missing env vars (check EB environment properties).
- **Migrations fail** → DB creds or networking issue.
